# Zestaw szablonów IG mytravelcast (stan 23.10.2026)

Przenośny zestaw do robienia grafik Instagrama mytravelcast w świeżym kontenerze.
Zasady pracy, rejestr i plan są w Projekcie: `claude/instagram/zasady-publikacji.md`,
`claude/instagram/rejestr-publikacji.md`, `claude/instagram/plan-pracy.md`.

## Start
```
curl -sSL -o kit.tar.gz https://raw.githubusercontent.com/fiemski/mytravelcast-media/main/szablony/kit.tar.gz
tar -xzf kit.tar.gz && bash kit/setup.sh
```

## Karuzela (1080x1350, 4 slajdy) – wzór IG-006 Japonia
- `karuzela/s1..s4.html` + `common.css`: skopiuj katalog, podmień teksty i zdjęcia.
- Pasek trasy (nasze przejście zamiast „czytaj dalej”):
  `python3 -c "from route import route_html; print(route_html(2,4,'NASTĘPNY PRZYSTANEK','Tekst'))"`, wklej do slajdu.
- Render: `python3 kit/render_carousel.py KATALOG IG-007-v1 4`, a potem obejrzyj `contact.jpg` i każdy slajd.

## Story (1080x1920) – wzór IG-005 Machu Picchu
- `story/story.html`: żółta góra z falą, zdjęcie od 380 px, nagłówek 110 px nowrap, 4 kolorowe chipy, granatowa pigułka z adresem.
- Render: `python3 kit/render_story.py story/story.html IG-008-v1.jpg`.

## Styl (decyzje Grześka)
- Jasno, słonecznie, kolorowo i kontrastowo, mocno rzucające się w oczy. Nigdy ponuro.
- Prawdziwe, efektowne zdjęcia miejsc, a nie rysunki ani zwykłe zatłoczone ulice.
- Bez „CZYTAJ DALEJ” i bez kopiowania fly4free. Bez „link w bio”.
- Treść na kilku slajdach, źródła i linki oficjalne w pierwszym komentarzu.

## Zdjęcia (tylko Unsplash, darmowa licencja; autor w komentarzu i na ostatnim slajdzie)
Kontener nie pobiera z CDN zdjęć, więc zdjęcie zgrywa się przez Chrome:
1. Otwórz `images.unsplash.com/photo-ID?w=1080&h=H&fit=crop&crop=entropy&q=90&fm=jpg`.
2. JS: img width = 1322.45px, height = naturalHeight*1.22449 (skala zrzutu 0.8167).
3. Najedź myszą na (1450,400), żeby kursor nie wszedł w kadr.
4. Zrzuty `save_to_disk` ze **scale: 1** przy przewinięciu 0 / 919 / reszta.
5. Sklej kafle w PIL, podbij: Color 1.2–1.25, Contrast 1.05–1.08. Obejrzyj wynik.

## Zrzut mapy mytravelcast
`STYLE='NATURA I TREKKING' SHIFT=20 python3 kit/mtc_shot.py AZJA LIS out.png 1600 1000`
(SHIFT = dni strzałką na suwaku, np. LIS+20 daje 20.11–3.12). Ocenę stylu odczytaj ze zrzutu i nie zgaduj.

## Hosting i publikacja
- Pliki: repo `fiemski/mytravelcast-media` (publiczne), URL `https://raw.githubusercontent.com/fiemski/mytravelcast-media/main/<plik>`.
  Po wgraniu sprawdź sha256 przez curl.
- Metricool (blogId 7603257, Europe/Warsaw): najpierw szkic (`draft:true`). Po „ZATWIERDZAM IG-xxx-vN”
  ustaw media na URL-e raw, alt-teksty, `draft:false` i termin. Story bez tekstu.
- Bez wyraźnej zgody na konkretną wersję nic nie publikujesz i nic nie planujesz do autopublikacji.
